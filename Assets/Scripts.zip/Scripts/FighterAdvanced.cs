using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FighterAdvanced : ScriptableObject
{
    public float _damage;
    public float _health;
    
}
