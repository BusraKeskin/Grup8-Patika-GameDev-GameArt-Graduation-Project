using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hero_v1 : Fighter
{
    private bool _checkCol;
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("iften oncee");
        if (other.gameObject.tag == gameObject.tag && _checkCol)
        {
            Debug.Log("oaaaa");
            Destroy(other.gameObject);
            //GameObject.Instantiate(Resources.Load("Prefabs/Hero_v2"), transform.position, Quaternion.identity);
            Destroy(gameObject);
            
        }
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        _checkCol = transform.GetComponent<DragAndDrop>()._checkCol;
    }
}
